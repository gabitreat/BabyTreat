# BabyTreat — agent instructions

## Ground rules

- The repo is the source of truth. Read `/decisions` before proposing anything.
- Do not implement a feature that has no Accepted ADR. Write the ADR first,
  ask for approval, then code.
- Any nutrition, feeding, allergy or developmental claim shown to a user must
  trace to a source listed in an ADR Evidence table (WHO, ESPGHAN, AAP, NHS,
  or peer-reviewed literature). Never invent thresholds, ages or portions.
- Never commit secrets, API keys, provisioning profiles or `.p12` files.

## Stack

- iOS 17+, Swift 5.9+, SwiftUI, Swift Concurrency.
- Persistence: SwiftData (offline-first).
- Tests: Swift Testing / XCTest. No PR without tests for logic.
- No third-party dependency without an ADR.

## Layout

```
BabyTreat.xcodeproj
Sources/
  App/            entry point, routing
  Features/       one folder per feature, view + model + tests
  Core/           models, persistence, services
  DesignSystem/   colors, type, components
decisions/        ADRs
```

## Workflow

1. Branch: `feat/<slug>` or `adr/<slug>`.
2. Conventional commits (`feat:`, `fix:`, `docs:`, `chore:`).
3. Small PRs. Link the ADR number in the description.
4. `xcodebuild test` must pass before requesting review.

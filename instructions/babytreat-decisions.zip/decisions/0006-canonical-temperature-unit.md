# 0006. Store temperature canonically in Celsius

- **Status:** Proposed
- **Date:** 2026-07-26
- **Severity:** Data integrity

## Context

`TemperatureReading` stores `value: Double` plus `unit: String`, set from the
`temperatureUnit` AppStorage at the moment of saving. `HistoryView` charts
`value` directly and never reads `unit`.

If a parent switches °C → °F in Settings, the same dataset then holds `37.0`
and `98.6` as comparable numbers. Charts, thresholds and any future fever
detection all break silently. The unit is a *presentation* preference; it should
never have entered storage.

## Decision

Store every reading in Celsius. Convert only at the display boundary. Keep the
`unit` field for one migration cycle to convert existing Fahrenheit rows, then
remove it.

Fever thresholds stay defined in Celsius in one place, not scattered across
views as they are now in `TemperatureView`.

## Evidence

| Claim | Source | Type | Link |
|-------|--------|------|------|
| Thresholds must be stated against a single scale and measurement site to be meaningful | To be filled — NICE Fever in under 5s (NG143) / AAP | Guideline | |

> Note: `TemperatureView` currently hardcodes 38.0 °C as the fever threshold and
> does not record the measurement site. Axillary, oral, tympanic and rectal
> readings are not interchangeable. Either record the site or drop the clinical
> labelling from the UI. Do not ship an un-sited fever judgement.

## Consequences

- Positive: one comparable number; charts and thresholds become correct.
- Negative: one-time SwiftData migration.

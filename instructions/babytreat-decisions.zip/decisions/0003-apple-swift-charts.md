# 0003. Use Apple Swift Charts; remove danielgindi/Charts

- **Status:** Proposed
- **Date:** 2026-07-26

## Context

`Package.swift` declares `danielgindi/Charts` from 5.0.0 and `Package.resolved`
pins 5.1.0. But the Tuist target declares `dependencies: []`, so the package is
never linked. Meanwhile `HistoryView.swift` does `import Charts` and uses
`Chart { RectangleMark(xStart:xEnd:yStart:yEnd:) }` — that is **Apple's Swift
Charts**, a system framework, not danielgindi.

So the third-party package is: (a) unused, (b) unlinked, and (c) shares the
module name `Charts` with the framework actually in use. If anyone ever adds it
to `dependencies`, `import Charts` becomes ambiguous and the build breaks.

## Decision

Charting uses Apple Swift Charts. Remove the `danielgindi/Charts` entry from
`Package.swift` and delete `Package.resolved`.

## Consequences

- Positive: removes a name collision waiting to happen; one less dependency.
- Negative: Swift Charts is iOS 16+ only — already satisfied by the iOS 17 target.

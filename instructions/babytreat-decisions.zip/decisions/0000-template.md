# NNNN. <Title>

- **Status:** Proposed
- **Date:** YYYY-MM-DD
- **Deciders:** <names>
- **Supersedes:** —
- **Superseded by:** —

## Context

What problem forced this decision? Constraints, deadlines, users affected.

## Options considered

| Option | Pros | Cons |
|--------|------|------|
| A | | |
| B | | |

## Decision

We will <do X>, because <reason>.

## Evidence

Required for any health, nutrition, safety, or developmental claim.

| Claim | Source | Type | Link |
|-------|--------|------|------|
| | WHO / ESPGHAN / AAP / RCT / meta-analysis | | |

## Consequences

- Positive:
- Negative / accepted risk:
- Revisit when:

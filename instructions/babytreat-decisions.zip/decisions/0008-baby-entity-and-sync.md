# 0008. Model the baby as an entity; plan for two caregivers

- **Status:** Proposed
- **Date:** 2026-07-26

## Context

`SettingsView` stores `babyName: String` and `babyAgeMonths: Int` in
`@AppStorage`. Three problems:

1. **Age is a stored integer.** It is correct on the day it is typed and wrong
   forever after. Age must be derived from a birth date.
2. **One baby only.** Twins and second children are not representable, and no
   record carries a baby reference.
3. **One device only.** No CloudKit. Two parents tracking the same baby is the
   normal case for this product, and today each phone holds a separate,
   diverging dataset — which is exactly the coordination gap ADR 0007 cites as a
   driver of dosing error.

## Decision

Add a `Baby` model with `name`, `birthDate`, `id`. Every record gains a `baby`
relationship. Derive age for display. Adopt CloudKit private database sync via
SwiftData.

Note: CloudKit-backed SwiftData requires all properties to be optional or have
defaults, and forbids `@Attribute(.unique)`. Doing this **before** the record
count grows is materially cheaper than doing it after.

## Consequences

- Positive: correct age, multi-baby, and the shared-view-of-truth the product
  needs.
- Negative: migration touches every model; CloudKit constrains schema shape.
- Revisit when: sharing beyond a single iCloud family is requested.

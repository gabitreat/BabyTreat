# 0001. Record decisions in Git

- **Status:** Accepted
- **Date:** 2026-07-26
- **Deciders:** BitTreat team

## Context

Decisions were spread across chats, notes and memory. They were not
searchable, not versioned, and not reviewable. For a product touching infant
health, we need an auditable trail of *what* was decided, *when*, and *on what
evidence*.

## Decision

All decisions are recorded as Architecture Decision Records in `/decisions`,
reviewed via pull request, and merged to `main`. Chats are input; the repo is
the source of truth.

## Consequences

- Positive: searchable history, review gate, evidence attached to claims.
- Negative: small friction per decision. Accepted.
- Revisit when: the team exceeds ~10 people or a formal QMS is required.

# Setup — 10 minutes

## 1. Push the decision structure

```bash
git clone https://github.com/BitTreat/BabyTreat.git
cd BabyTreat
# copy decisions/, CLAUDE.md, .github/ into the repo root
git checkout -b chore/decisions
git add . && git commit -m "chore: add ADR structure, agent rules, iOS CI"
git push -u origin chore/decisions
```

Open the PR, merge it. From now on: no decision exists until it is on `main`.

## 2. Start the remote session

On your Mac (Xcode 16 + Command Line Tools installed):

```bash
npm install -g @anthropic-ai/claude-code
cd ~/dev/BabyTreat
claude
```

Then drive it from your phone: the Claude mobile app can attach to that
session, so the Mac does the building and you stay remote.

## 3. First prompt for the session

> Read decisions/ and CLAUDE.md. Create the Xcode project BabyTreat
> (iOS 17, SwiftUI, SwiftData) with the folder layout in CLAUDE.md, one
> smoke test, and confirm `xcodebuild test` passes. Do not add features yet.

## 4. Then, per feature

> Draft an ADR for <feature>, status Proposed, with an Evidence table.
> Stop and wait for approval before writing code.
